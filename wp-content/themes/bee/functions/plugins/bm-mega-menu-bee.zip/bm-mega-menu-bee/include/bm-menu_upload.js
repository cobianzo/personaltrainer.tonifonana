/***********************************************
 *
 *  
 * 除非你知道在干嘛
 * 否则请不要动代码
 * 
 ***********************************************/
jQuery(document).ready(function($) {
	$(".thickbox").each(function(index, element) {
		$(this).click(function(){
			$(".thickbox").siblings().removeAttr("id");
			$(this).next("a").attr("id","get_img");
			$(this).nextAll("input").attr("id","get_val");
		});
	});
	$(".thickbox").live("click",function(){
		$(".thickbox").siblings().removeAttr("id");
		$(this).next("a").attr("id","get_img");
		$(this).nextAll("input").attr("id","get_val");
	});
	$(".del-thumb").each(function(index, element) {
		$(this).click(function(){
			if($(this).find("img").length)
				if(confirm("Do you want delete it?"))
					$(this).html("").siblings("input").val("");
		});
	});	
	$(".del-thumb").live("click",function(){
		if($(this).find("img").length)
			if(confirm("Do you want delete it?"))
				$(this).html("").siblings("input").val("");
	});
	$(".slidetoggle").each(function(index, element) {
		var $t = $(this);
		$t.find(".savesend input").click(function(){
			window.parent.document.getElementById("TB_closeWindowButton").click();
			$val = $t.find(".urlfield").val();
			$html = "<img src='"+$val+"' />";
			window.parent.document.getElementById("get_img").innerHTML	= $html;
			window.parent.document.getElementById("get_val").value		= $val;
		});
	});
	$(".savesend input").live("click",function(){
		window.parent.document.getElementById("TB_closeWindowButton").click();
		$val = $(this).parent().parent().parent().find(".urlfield").val();
		if($val=="undefined")
		$val = $(this).parent().parent().find(".urlfield").val();
		$html = "<img src='"+$val+"' />";
		window.parent.document.getElementById("get_img").innerHTML	= $html;
		window.parent.document.getElementById("get_val").value		= $val;
	});
});