/***********************************************
 *
 *  
 * 除非你知道在干嘛
 * 否则请不要动代码
 * 
 ***********************************************/
jQuery(document).ready(function($) {
	var bls_menu_isMega = {
		callTimeout: false,
		//改变时
		callChange: function(){
			$('.edit-menu-item-isMega','#menu-to-edit').on('change', function(){
				var checkbox = $(this),
					container = checkbox.parents('.menu-item:eq(0)');
				if(checkbox.is(':checked')){
					container.addClass('isMega');
				} else {
					container.removeClass('isMega');
				}
				bls_menu_isMega.call();
			});
		},
		//菜单序列改变时
		callInit: function(){
            $(document).on('mouseup', '.menu-item-bar', function(event, ui){
				if(!$(event.target).is('a')){
					clearTimeout(bls_menu_isMega.callTimeout);
					bls_menu_isMega.callTimeout = setTimeout(bls_menu_isMega.call, 500);
				}
			});
		},
		//初始化
		callOn: function(){
            $('.checkOn','.menu-item-depth-0').each(function(index, element) {
				container = $(this).parents('.menu-item:eq(0)');
				if($(this).is(':checked')){
					container.addClass('isMega');
				} else {
					container.removeClass('isMega');
				}
				bls_menu_isMega.call();                
            });
		},
		//实现我们的功能
		call : function(){
			var Items = $('.menu-item','#menu-to-edit');
			Items.each(function(i){
				var $t = $(this);
				if(!$t.is('.menu-item-depth-0')){
					//如果它的前一项是.isMega或者.mega_active,则加上.mega_active
					var prevItem = Items.filter(':eq('+(i-1)+')');
					if(prevItem.is('.isMega') || prevItem.is('.mega_active')){
						$t.addClass('mega_active');
					} else {
						$t.removeClass('mega_active');
					}
				}
			});
		}
	};
	bls_menu_isMega.callChange();
	bls_menu_isMega.callInit();
	bls_menu_isMega.callOn();
	bls_menu_isMega.call();
});