<?php
/*
 * 
 * load menu expand Class
*/
class blsMenu{
	function __construct(){
		//Variable
		$this->URL = plugins_url().'/'.dirname( str_replace(basename( __FILE__ ),"",plugin_basename( __FILE__ ) ) ) . '/';
		$this->val_op = array();
		load_plugin_textdomain( 'bls-menu' , false , $this->URL. 'languages/' );

		//load wpadmin js css
		add_action( 'admin_enqueue_scripts', array( $this , 'my_enqueue') );
		
		//replace wordpress original menu Expert-function 
		add_filter('wp_nav_menu_args', 'bls_menu_export', 100);
		
		//replace wordpress original menu Save-function 
		add_action( 'wp_update_nav_menu_item', array( $this, 'updateOPval'), 100, 3);
		
		// replace wordpress original menu Structure Making-function 
		add_filter( 'wp_edit_nav_menu_walker', array( $this, 'modify_new_walker') , 100);
		add_action( 'bls_menu_item_options' , array( $this, 'diy_menu') , 100);
		
		//ourself Variable
		$this->op = array(
			'menu-item-anchor'				=> '',
			'menu-item-thumb'				=> '',
			'menu-item-isMega'				=> 'off',
			'menu-item-newrow'				=> 'off',
			'menu-item-notext'				=> 'off',
			'menu-item-nolink'				=> 'off'
		);
	}
	
	//load wp-admin js css
	function my_enqueue($hook) {
		wp_enqueue_script('jquery');
		wp_enqueue_script('media-upload');
		wp_enqueue_script('thickbox');
		wp_enqueue_script('bls-menu_upload' , $this->URL.'include/bm-menu_upload.js',  array(), BLSMENU_VERSION);
		if($hook=="nav-menus.php")
		wp_enqueue_script('bls-menu_mega' , $this->URL.'include/bm-menu_mega.js',  array(), BLSMENU_VERSION);
		wp_enqueue_style( 'thickbox');
        wp_enqueue_style( 'bls-menu_admin_css', $this->URL.'include/bm-menu.admin.css', array(), BLSMENU_VERSION);
	}

	//replace wordpress default menu Structure Making-function 
	function modify_new_walker($name){
		return 'new_edit_nav_menu_walker';
	}
	
	// Add the needed menu Structure function
	function diy_menu( $item_id ){
		?>
        <div class="bls-menus">
			<?php $this->push_menu( $item_id ); ?>
		</div>
	<?php
	}
	// make the array to expert Structure
	function push_menu( $item_id ){
		$this->make_menu(
			'anchor', 
			$item_id, 
			array(
				'level'	=> '0', 
				'lab'	=> __( 'Anchor' , 'ux' ), 
				'type' 	=> 'text'
			)
		);
		$this->make_menu(
			'thumb', 
			$item_id, 
			array(
				'level'	=> '0', 
				'lab'	=> __( 'Icon' , 'ux' ), 
				'type' 	=> 'file'
			)
		);
		$this->make_menu(
			'isMega', 
			$item_id, 
			array(
				'level'	=> '0',
				'lab'	=> __( 'Activate Mega Menu' , 'ux' ), 
				'type' 	=> 'checkbox',
				'start' => 'off'
			)
		);
		$this->make_menu(
			'newrow', 
			$item_id, 
			array(
				'level'	=> '0',
				'lab'	=> __( 'Start a new row' , 'ux' ), 
				'type' 	=> 'checkbox',
				'start' => 'off'
			)
		);
		$this->make_menu(
			'notext', 
			$item_id, 
			array(
				'level'	=> '0',
				'lab'	=> __( 'Hide' , 'ux' ), 
				'type' 	=> 'checkbox',
				'start' => 'off'
			)
		);
		$this->make_menu(
			'nolink', 
			$item_id, 
			array(
				'level'	=> '0',
				'lab'	=> __( 'Don\'t link' , 'bls-menu' ), 
				'type' 	=> 'checkbox',
				'start' => 'off'
			)
		);
		
	}
	//make our menu
	function make_menu( $name, $item_id, $args ){
		extract( wp_parse_args(
			$args, array(
				'level'	=> '0',
				'lab'	=> '',
				'type'	=> 'text',
				'ops'	=>	array(),
				'start'	=> '',
			) )
		);

		$getVal = $this->getOPval( $item_id , $name );
		switch($type) {
			case 'text':
		?>
                <p class="description description-text description-bls description-<?php echo $name; ?>">
					<label for="edit-menu-item-title-<?php echo $name;?>">
						<?php echo $lab;?><br />
						<input type="text" id="edit-menu-item-<?php echo $name;?>-<?php echo $item_id;?>" class="widefat edit-menu-item-title" name="menu-item-<?php echo $name;?>[<?php echo $item_id;?>]" value="<?php echo htmlspecialchars( $getVal );?>">
					</label>
				</p>
        <?php
			break;
			case 'textarea':
		?>
				<p class="description description-textarea description-bls description-<?php echo $name; ?>">
					<label for="edit-menu-item-title-<?php echo $name;?>">
						<?php echo $lab;?><br />
						<textarea id="edit-menu-item-<?php echo $name;?>-<?php echo $item_id;
						?>" class="edit-menu-item-<?php echo $name;
						?>" name="menu-item-<?php echo $name;?>[<?php echo $item_id;?>]" ><?php
						echo htmlspecialchars( $getVal );
						?></textarea>
					</label>
				</p>
		<?php
			break;
			case 'checkbox':
		?>
				<p class="description description-checkbox description-bls description-<?php echo $name; ?>">
					<label for="edit-menu-item-title-<?php echo $name;?>">
						<input type="checkbox" id="edit-menu-item-<?php echo $name;?>-<?php echo $item_id;
						?>" name="menu-item-<?php echo $name;?>[<?php echo $item_id;?>]" <?php
						if ( $getVal == 'on')
						echo 'class="checkOn edit-menu-item-'.$name.'" checked="checked"';
						else
						echo 'class="edit-menu-item-'.$name.'"';
						?> />&nbsp;&nbsp;&nbsp;<?php echo $lab;?>
					</label>
				</p>
		<?php
			break;
			case 'select':
		?>
				<p class="description description-select description-bls description-<?php echo $name; ?>">
					<label for="edit-menu-item-title-<?php echo $name;?>">
						<?php echo $lab;?><br />
						<select id="edit-menu-item-<?php echo $name; ?>-<?php echo $item_id;
						?>" class="edit-menu-item-<?php echo $name; ?>" name="menu-item-<?php echo $name;?>[<?php echo $item_id;?>]">
						<?php foreach( $ops as $vals => $tit ): ?>
							<option value="<?php echo $vals; ?>" <?php if( $getVal == $vals ) echo 'selected="selected"'; ?> ><?php echo $tit; ?></option>
                        <?php endforeach; ?>
						</select>
					</label>
				</p>
		<?php
			break;
			case 'file':
				if( !empty($getVal) )
					$out = '<a class="del-thumb bls_button show-thumb-' . $item_id . '"><img src="' . $getVal . '" /></a>';
				else
					$out = '<a class="del-thumb bls_button show-thumb-' . $item_id . '"></a>';
		?>
                <p class="description description-file description-bls description-<?php echo $name; ?>">
					<label for="edit-menu-item-title-<?php echo $name;?>">
						<?php echo $lab;?><br />
                        <a class="thickbox set-menu-item-thumb bls_button" id="set-thumb-<?php echo $item_id;?>" onClick="tb_show('<?php _e('Image upload', 'bls-menu'); ?>','<?php bloginfo('url');?>/wp-admin/media-upload.php?TB_iframe=1',false);" title="<?php _e("Set Thumbnail", 'bls-menu' ); ?>">...</a>
						<?php
						echo $out;
						?>
						<input type="hidden" class="edit-menu-item-<?php echo $name;?>" name="menu-item-<?php echo $name;?>[<?php echo $item_id;?>]" value="<?php echo htmlspecialchars( $getVal );?>">
					</label>
				</p>
		<?php
			break;
		}
	}
	/*
	 *   Replace wordpress original menu's search,save function
	 *   Save all value check by $_POST
	 * @param int $menu_id
	 * @param int $name
	 */
	//return the _postmeta table's meta_value  , (if) post_id = $item_id;meta_key='menu-item-'.$name;
	function getOPval( $item_id , $name ){
		$options = 'menu-item-'.$name;
		$get_options = get_post_meta( $item_id , $options, true );
		return !empty( $get_options ) ? stripslashes( $get_options ) : $this->op[ $options ];
		
	}
	//update _postmeta  table's meta_value  ,(if)  post_id = $item_id;meta_key=array_keys($this->op);
	function updateOPval($menu_id, $item_id){
		$check = apply_filters('bls_menu_post_meta_fields', array_keys($this->op), $menu_id, $item_id);
		foreach ( $check as $key )
		{
			$value = (!isset($_POST[$key][$item_id])) ? $this->op[$key] : $_POST[$key][$item_id];
			update_post_meta( $item_id, $key, $value );
		}
	}
}

if( !class_exists( 'new_edit_nav_menu_walker' ) )
{
/**
 * Create HTML list of nav menu input items.
 * This walker is a clone of the wordpress edit menu walker with some options appended, so the user can choose to create mega menus
 *
 * @package Expand Wordpress original Class
 * @since 1.0
 * @uses Walker_Nav_Menu
 */
	class new_edit_nav_menu_walker extends Walker_Nav_Menu {
	/**
	 * Starts the list before the elements are added.
	 *
	 * @see Walker_Nav_Menu::start_lvl()
	 *
	 * @since 3.0.0
	 *
	 * @param string $output Passed by reference.
	 * @param int    $depth  Depth of menu item. Used for padding.
	 * @param array  $args   Not used.
	 */
	function start_lvl( &$output, $depth = 0, $args = array() ) {}

	/**
	 * Ends the list of after the elements are added.
	 *
	 * @see Walker_Nav_Menu::end_lvl()
	 *
	 * @since 3.0.0
	 *
	 * @param string $output Passed by reference.
	 * @param int    $depth  Depth of menu item. Used for padding.
	 * @param array  $args   Not used.
	 */
	function end_lvl( &$output, $depth = 0, $args = array() ) {}

	/**
	 * Start the element output.
	 *
	 * @see Walker_Nav_Menu::start_el()
	 * @since 3.0.0
	 *
	 * @param string $output Passed by reference. Used to append additional content.
	 * @param object $item   Menu item data object.
	 * @param int    $depth  Depth of menu item. Used for padding.
	 * @param array  $args   Not used.
	 * @param int    $id     Not used.
	 */
	function start_el( &$output, $item, $depth = 0, $args = array(), $id = 0 ) {
		global $_wp_nav_menu_max_depth;
		$_wp_nav_menu_max_depth = $depth > $_wp_nav_menu_max_depth ? $depth : $_wp_nav_menu_max_depth;

		ob_start();
		$item_id = esc_attr( $item->ID );
		$removed_args = array(
			'action',
			'customlink-tab',
			'edit-menu-item',
			'menu-item',
			'page-tab',
			'_wpnonce',
		);

		$original_title = '';
		if ( 'taxonomy' == $item->type ) {
			$original_title = get_term_field( 'name', $item->object_id, $item->object, 'raw' );
			if ( is_wp_error( $original_title ) )
				$original_title = false;
		} elseif ( 'post_type' == $item->type ) {
			$original_object = get_post( $item->object_id );
			$original_title = get_the_title( $original_object->ID );
		}

		$classes = array(
			'menu-item menu-item-depth-' . $depth,
			'menu-item-' . esc_attr( $item->object ),
			'menu-item-edit-' . ( ( isset( $_GET['edit-menu-item'] ) && $item_id == $_GET['edit-menu-item'] ) ? 'active' : 'inactive'),
		);

		$title = $item->title;

		if ( ! empty( $item->_invalid ) ) {
			$classes[] = 'menu-item-invalid';
			/* translators: %s: title of menu item which is invalid */
			$title = sprintf( __( '%s (Invalid)' ), $item->title );
		} elseif ( isset( $item->post_status ) && 'draft' == $item->post_status ) {
			$classes[] = 'pending';
			/* translators: %s: title of menu item in draft status */
			$title = sprintf( __('%s (Pending)'), $item->title );
		}

		$title = ( ! isset( $item->label ) || '' == $item->label ) ? $title : $item->label;

		$submenu_text = '';
		if ( 0 == $depth )
			$submenu_text = 'style="display: none;"';

		?>
		<li id="menu-item-<?php echo $item_id; ?>" class="<?php echo implode(' ', $classes ); ?>">
			<dl class="menu-item-bar">
				<dt class="menu-item-handle">
					<span class="item-title"><span class="menu-item-title"><?php echo esc_html( $title ); ?></span> <span class="is-submenu" <?php echo $submenu_text; ?>><?php _e( 'sub item' ); ?></span></span>
					<span class="item-controls">
						<span class="item-type"><?php echo esc_html( $item->type_label ); ?></span>
						<span class="item-order hide-if-js">
							<a href="<?php
								echo wp_nonce_url(
									add_query_arg(
										array(
											'action' => 'move-up-menu-item',
											'menu-item' => $item_id,
										),
										remove_query_arg($removed_args, admin_url( 'nav-menus.php' ) )
									),
									'move-menu_item'
								);
							?>" class="item-move-up"><abbr title="<?php esc_attr_e('Move up'); ?>">&#8593;</abbr></a>
							|

							<a href="<?php
								echo wp_nonce_url(
									add_query_arg(
										array(
											'action' => 'move-down-menu-item',
											'menu-item' => $item_id,
										),
										remove_query_arg($removed_args, admin_url( 'nav-menus.php' ) )
									),
									'move-menu_item'
								);
							?>" class="item-move-down"><abbr title="<?php esc_attr_e('Move down'); ?>">&#8595;</abbr></a>
						</span>
						<a class="item-edit" id="edit-<?php echo $item_id; ?>" title="<?php esc_attr_e('Edit Menu Item'); ?>" href="<?php
							echo ( isset( $_GET['edit-menu-item'] ) && $item_id == $_GET['edit-menu-item'] ) ? admin_url( 'nav-menus.php' ) : add_query_arg( 'edit-menu-item', $item_id, remove_query_arg( $removed_args, admin_url( 'nav-menus.php#menu-item-settings-' . $item_id ) ) );
						?>"><?php _e( 'Edit Menu Item' ); ?></a>
					</span>
				</dt>
			</dl>

			<div class="menu-item-settings" id="menu-item-settings-<?php echo $item_id; ?>">
				<?php if( 'custom' == $item->type ) : ?>
					<p class="field-url description description-wide">
						<label for="edit-menu-item-url-<?php echo $item_id; ?>">
							<?php _e( 'URL' ); ?><br />
							<input type="text" id="edit-menu-item-url-<?php echo $item_id; ?>" class="widefat code edit-menu-item-url" name="menu-item-url[<?php echo $item_id; ?>]" value="<?php echo esc_attr( $item->url ); ?>" />
						</label>
					</p>
				<?php endif; ?>
				<p class="description description-thin">
					<label for="edit-menu-item-title-<?php echo $item_id; ?>">
						<?php _e( 'Navigation Label' ); ?><br />
						<input type="text" id="edit-menu-item-title-<?php echo $item_id; ?>" class="widefat edit-menu-item-title" name="menu-item-title[<?php echo $item_id; ?>]" value="<?php echo esc_attr( $item->title ); ?>" />
					</label>
				</p>
				<p class="description description-thin">
					<label for="edit-menu-item-attr-title-<?php echo $item_id; ?>">
						<?php _e( 'Title Attribute' ); ?><br />
						<input type="text" id="edit-menu-item-attr-title-<?php echo $item_id; ?>" class="widefat edit-menu-item-attr-title" name="menu-item-attr-title[<?php echo $item_id; ?>]" value="<?php echo esc_attr( $item->post_excerpt ); ?>" />
					</label>
				</p>
				<p class="field-link-target description">
					<label for="edit-menu-item-target-<?php echo $item_id; ?>">
						<input type="checkbox" id="edit-menu-item-target-<?php echo $item_id; ?>" value="_blank" name="menu-item-target[<?php echo $item_id; ?>]"<?php checked( $item->target, '_blank' ); ?> />
						<?php _e( 'Open link in a new window/tab' ); ?>
					</label>
				</p>
				<p class="field-css-classes description description-thin">
					<label for="edit-menu-item-classes-<?php echo $item_id; ?>">
						<?php _e( 'CSS Classes (optional)' ); ?><br />
						<input type="text" id="edit-menu-item-classes-<?php echo $item_id; ?>" class="widefat code edit-menu-item-classes" name="menu-item-classes[<?php echo $item_id; ?>]" value="<?php echo esc_attr( implode(' ', $item->classes ) ); ?>" />
					</label>
				</p>
				<p class="field-xfn description description-thin">
					<label for="edit-menu-item-xfn-<?php echo $item_id; ?>">
						<?php _e( 'Link Relationship (XFN)' ); ?><br />
						<input type="text" id="edit-menu-item-xfn-<?php echo $item_id; ?>" class="widefat code edit-menu-item-xfn" name="menu-item-xfn[<?php echo $item_id; ?>]" value="<?php echo esc_attr( $item->xfn ); ?>" />
					</label>
				</p>
				<p class="field-description description description-wide">
					<label for="edit-menu-item-description-<?php echo $item_id; ?>">
						<?php _e( 'Description' ); ?><br />
						<textarea id="edit-menu-item-description-<?php echo $item_id; ?>" class="widefat edit-menu-item-description" rows="3" cols="20" name="menu-item-description[<?php echo $item_id; ?>]"><?php echo esc_html( $item->description ); // textarea_escaped ?></textarea>
						<span class="description"><?php _e('The description will be displayed in the menu if the current theme supports it.'); ?></span>
					</label>
				</p>
                <?php do_action( 'bls_menu_item_options', $item_id );?>
				<p class="field-move hide-if-no-js description description-wide">
					<label>
						<span><?php _e( 'Move' ); ?></span>
						<a href="#" class="menus-move-up"><?php _e( 'Up one' ); ?></a>
						<a href="#" class="menus-move-down"><?php _e( 'Down one' ); ?></a>
						<a href="#" class="menus-move-left"></a>
						<a href="#" class="menus-move-right"></a>
						<a href="#" class="menus-move-top"><?php _e( 'To the top' ); ?></a>
					</label>
				</p>

				<div class="menu-item-actions description-wide submitbox">
					<?php if( 'custom' != $item->type && $original_title !== false ) : ?>
						<p class="link-to-original">
							<?php printf( __('Original: %s'), '<a href="' . esc_attr( $item->url ) . '">' . esc_html( $original_title ) . '</a>' ); ?>
						</p>
					<?php endif; ?>
					<a class="item-delete submitdelete deletion" id="delete-<?php echo $item_id; ?>" href="<?php
					echo wp_nonce_url(
						add_query_arg(
							array(
								'action' => 'delete-menu-item',
								'menu-item' => $item_id,
							),
							admin_url( 'nav-menus.php' )
						),
						'delete-menu_item_' . $item_id
					); ?>"><?php _e( 'Remove' ); ?></a> <span class="meta-sep hide-if-no-js"> | </span> <a class="item-cancel submitcancel hide-if-no-js" id="cancel-<?php echo $item_id; ?>" href="<?php echo esc_url( add_query_arg( array( 'edit-menu-item' => $item_id, 'cancel' => time() ), admin_url( 'nav-menus.php' ) ) );
						?>#menu-item-settings-<?php echo $item_id; ?>"><?php _e('Cancel'); ?></a>
				</div>

				<input class="menu-item-data-db-id" type="hidden" name="menu-item-db-id[<?php echo $item_id; ?>]" value="<?php echo $item_id; ?>" />
				<input class="menu-item-data-object-id" type="hidden" name="menu-item-object-id[<?php echo $item_id; ?>]" value="<?php echo esc_attr( $item->object_id ); ?>" />
				<input class="menu-item-data-object" type="hidden" name="menu-item-object[<?php echo $item_id; ?>]" value="<?php echo esc_attr( $item->object ); ?>" />
				<input class="menu-item-data-parent-id" type="hidden" name="menu-item-parent-id[<?php echo $item_id; ?>]" value="<?php echo esc_attr( $item->menu_item_parent ); ?>" />
				<input class="menu-item-data-position" type="hidden" name="menu-item-position[<?php echo $item_id; ?>]" value="<?php echo esc_attr( $item->menu_order ); ?>" />
				<input class="menu-item-data-type" type="hidden" name="menu-item-type[<?php echo $item_id; ?>]" value="<?php echo esc_attr( $item->type ); ?>" />
			</div><!-- .menu-item-settings-->
			<ul class="menu-item-transport"></ul>
		<?php
		$output .= ob_get_clean();
	}
	}
} // Walker_Nav_Menu_Edit