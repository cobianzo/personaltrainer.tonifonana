<?php
/*
Plugin Name: BM MEGA MENU for Bee wp theme
Plugin URI: http://www.uiueux.com/
Description: Create highly customizable Mega Menus through an easy-to-use WordPress Plugin.
Version: 2.9.7
Author: uiueux
Author URI: http://www.uiueux.com/
License: You should have purchased a license from Themeforest, author:bwsm
*/

define( 'BLSMENU_VERSION',		'2.9.7');//
define( 'BLSMENU_IMG_W_H',		'16' );//icon images size
define( 'BLSMENU_CSS_JS',		true );//not use 

//
if(BLSMENU_CSS_JS){
	//add_action( 'get_header', 'head_add_css_js' );
	//add_action( 'get_footer', 'foot_add_css_js' );
}
//
function head_add_css_js() {
	global $blsMenu;
	$urls = $blsMenu->URL.'export/';
	wp_enqueue_script('jquery');
	echo '
   
	';
}
//
function foot_add_css_js() {
	global $blsMenu;
	$urls = $blsMenu->URL.'export/';
	echo '
    
	';
}


require_once( 'include/core.php' );
require_once( 'export/bm-menu.php' );
$blsMenu = new blsMenu();
global $blsMenu;
