<?php
/*
 *  
 *  Export to theme
*/
//Replace original Wordpress menu front end function 
function bls_menu_export( $args ){
	$walker = apply_filters("bls-menu_mega_menu_walker", "blsMenu_walker");
	if($walker){
		$args['container_id']	= 'navi_wrap';
		$args['menu_class'] = 'menu';
		$args['walker'] = new $walker();
	}
	return $args;
}
if( !class_exists( 'blsMenu_walker' ) )
{
	/**
	 * Replace original Wordpress part of Walker Class
	 * @package WordPress
	 * @since 1.0.0
	 * @uses Walker
	 * Execution process: start_el > start_lvl > [ start_el > start_lvl > ...... > end_lvl > end_el > ] end_lvl > end_el
	 */
	class blsMenu_walker extends Walker {
		/**
		 * @ Walker::$tree_type
		 * @ declare $tree_type field
		 */
		var $tree_type = array( 'post_type', 'taxonomy', 'custom' );

		/**
		 * @ Walker::$db_fields
		 * @ Analytical field.
		 * @ declare $db_fields field
		 */
		var $db_fields = array( 'parent' => 'menu_item_parent', 'id' => 'db_id' );

		/**
		 * @   declare needed field 
		 */
		var $anchor = "",
			$thumb = "",
			$isMega = "off",
			$newrow = "off",
			$notext = "off",
			$nolink = "off",
			$columns = 0,
			$rowcla = "",
			$colcls = "",
			$depth = "",
			//export the html
			$mege_div = '<div class="ux-maga-menu container">',//when mega actived, around the div
			$row_div = '<div class="row-fluid {replace_class}">';//when mega actived, around the div to level3
		
		/**
		 * @ Walker::start_lvl()
		 * @   Changing the menu's export $output
		 * @ $depth(int) field means menu level
		 */
		function start_lvl(&$output, $depth = 0, $args = array()) {
			$this->indent = str_repeat("\t", $depth);
			if($depth === 0 && $this->isMega == "on") $output .= "\n$this->indent<div class='ux-maga-menu container'>";
			$output .= "\n$this->indent<ul class=\"sub-menu\">\n";
			if($depth === 0 && $this->isMega == "on") $output .= "$this->indent<div class='{replace_class}'>\n";
		}
		/**
		 * @ Walker::end_lvl()
		 * @ Changing the menu's export $output
		 * @ $depth(int) field means menu level
		 */
		function end_lvl(&$output, $depth = 0, $args = array()) {
			if($depth === 0 && $this->isMega == "on") $output .= "\n$this->indent</div>";
			$output .= "\n$this->indent</ul>\n";
			if($depth === 0){
				//filter the  {replace_class} on the line top
				//6 columns same as 5  columns
				//5 columns ： fivecolumns		span2
				//4 columns ： fourcolumns		span3
				//3 columns ： treecolumns		span4
				//2 columns ： twocolumns		span6
				//1 column： onecolumn		span12
				if($this->isMega == "on")
				{
					switch($this->columns){
						case 1:
							$this->colcla = "row-fluid onecolumn";
							$this->rowcla = "span12";
						break;
						case 2:
							$this->colcla = "row-fluid twocolumns";
							$this->rowcla = "span6";
						break;
						case 3:
							$this->colcla = "row-fluid treecolumns";
							$this->rowcla = "span4";
						break;
						case 4:
							$this->colcla = "row-fluid fourcolumns";
							$this->rowcla = "span3";
						break;
						case 5:
							$this->colcla = "row-fluid fivecolumns";
							$this->rowcla = "span2";
						break;
						default:
							$this->colcla = "row-fluid fivecolumns";
							$this->rowcla = "span2";
						break;
					}
					$output .= "$this->indent</div><!--End $this->colcla-->\n";
					$output = str_replace("{replace_class}", $this->colcla, $output);
					$output = str_replace("{replace_spans}", $this->rowcla, $output);
				}
				$this->columns = 0;
				$this->colcla = "";
				$this->rowcla = "";
			}
		}

		/**
		 * @ Walker::start_el()
		 * @ Changing the menu's export $output
		 * @  $item Restructure
		 * @ $depth(int) : this  field means menu level
		 * @ $current_page is $item 's ID
		 * @ $args :  this array is default value of menu Transmission
		 */
		function start_el(&$output, $item, $depth = 0, $args = array(), $current_object_id = 0 ) {
			global $wp_query;
			$this->indent = str_repeat("\t", $depth);
			//get the settings value
			//if(get_post_meta( $item->ID, 'menu-item-anchor', true)!=''){
			//if(strpos($_SERVER["HTTP_USER_AGENT"],"MSIE 8.0")){
			//	$this->anchor	= $item->object == "page" ? "#".get_post_meta( $item->ID, 'menu-item-anchor', true) : '';
			//}else{
				$this->anchor	= $item->object == "page" ? get_post_meta( $item->ID, 'menu-item-anchor', true) : '';
			//}
			//}
			if( $depth === 0 || $depth === 1 || $depth === 2 )
			$this->thumb	= get_post_meta( $item->ID, 'menu-item-thumb' , true);
			if( $depth === 0 )
			$this->isMega	= get_post_meta( $item->ID, 'menu-item-isMega', true);
			if( $depth === 1 ){
			$this->newrow	= get_post_meta( $item->ID, 'menu-item-newrow', true);
			$this->notext	= get_post_meta( $item->ID, 'menu-item-notext', true);
			}
			$this->nolink	= get_post_meta( $item->ID, 'menu-item-nolink', true);
			//构建菜单
			$add_class = "";
			switch($depth){
				case 0:
					// when mage is actived
					if( $this->isMega == "on"){
						// add class name
						$add_class .= " isMega";
					}
					//if has the thumbnail
					if( !empty( $this->thumb ) ){
						$item->title = "<img src='$this->thumb' width='".BLSMENU_IMG_W_H."' height='".BLSMENU_IMG_W_H."' />".$item->title;
					}
				break;
				case 1:
					//when mage is actived
					if( $this->isMega == "on"){
						//if has newrow
						if( $this->newrow == "on" ){
							
							//filter the  {replace_class},{replace_spans} on the line top
							//6 columns same as 5  columns
							//5 columns ： fivecolumns		span2
							//4 columns ： fourcolumns		span3
							//3 columns ： treecolumns		span4
							//2 columns ： twocolumns		span6
							//1 column： onecolumn		span12
							switch($this->columns){
								case 0:
									$this->colcla = "";
									$this->rowcla = "";
								break;
								case 1:
									$this->colcla = "row-fluid onecolumn";
									$this->rowcla = "span12";
								break;
								case 2:
									$this->colcla = "row-fluid twocolumns";
									$this->rowcla = "span6";
								break;
								case 3:
									$this->colcla = "row-fluid treecolumns";
									$this->rowcla = "span4";
								break;
								case 4:
									$this->colcla = "row-fluid fourcolumns";
									$this->rowcla = "span3";
								break;
								case 5:
									$this->colcla = "row-fluid fivecolumns";
									$this->rowcla = "span2";
								break;
								default:
									$this->colcla = "row-fluid fivecolumns";
									$this->rowcla = "span2";
								break;
							}
							// replcing the Class
							$output = str_replace("{replace_class}", $this->colcla, $output);
							$output = str_replace("{replace_spans}", $this->rowcla, $output);
							$output .= "\n$this->indent</div><!--End $this->colcla-->\n$this->indent<div class='{replace_class}'>\n";
							$this->columns = 1;
							// add class
							$add_class .= " newrow";
						} else {
							$this->columns ++;
						}
						//if hide(notext)
						if( $this->notext == "on" ){
							$item->title = "";
							$add_class .= " notext";
						}
						//add class
						$add_class .= " {replace_spans}";

						//if has the thumbnail
						if( !empty( $this->thumb ) ){
							$item->title = "<img class='maga_thumb' src='$this->thumb' width='".BLSMENU_IMG_W_H."' height='".BLSMENU_IMG_W_H."' /><span class='mega-item-txt'>".$item->title."</span>";
						}else{
							$item->title = "<span class='mega-item-txt'>".$item->title."</span>";
						}
					}
					
				break;

				case 2:
					if( $this->isMega == "on"){

					if( !empty( $this->thumb ) ){
						$item->title = "<img class='maga_thumb' src='$this->thumb' width='".BLSMENU_IMG_W_H."' height='".BLSMENU_IMG_W_H."' /><span class='mega-item-txt'>".$item->title."</span>";
					}else{
						$item->title = "<span class='mega-item-txt'>".$item->title."</span>";
					}
						}

				break;/**/
			}
			$attributes  = ! empty( $item->attr_title ) ? ' title="'  . esc_attr( $item->attr_title ) .'"' : '';
			$attributes .= ! empty( $item->target )     ? ' target="' . esc_attr( $item->target     ) .'"' : '';
			$attributes .= ! empty( $item->xfn )        ? ' rel="'    . esc_attr( $item->xfn        ) .'"' : '';
			//$attributes .= $this->notext == "on"        ? ' class="notext"'                                 : '';
			$attributes .= (! empty( $item->url ) && $this->nolink == "off" )       ? ' href="'   . esc_attr( $item->url ) .$this->anchor.'"' : ' class="no-link"';
			
			$item_output = @$args->before;
			$item_output .= '<a'. $attributes .'>';
			$item_output .= @$args->link_before . @apply_filters( 'the_title', @$item->title, @$item->ID ) . @$args->link_after;
			$item_output .= '</a>';
			$item_output .= @$args->after;
			
			$classes = empty( $item->classes ) ? array() : (array) $item->classes;
			$class_names = join( ' ', apply_filters( 'nav_menu_css_class', array_filter( $classes ), $item ) );
			$class_names = ' class="'. esc_attr( $class_names ) .$add_class.'"';
			$output .= $this->indent . '<li id="menu-item-'. $item->ID . '"' . $class_names .'>';
			$output .= apply_filters( 'walker_nav_menu_start_el', $item_output, $item, $depth, $args );
		}

		/**
		 * @ Walker::end_el()
		 * @ Changing the menu's export $output
		 * @  $item Restructure
		 * @ $depth(int) : this  field means menu level
		 * @ $current_page is $item 's ID
		 * @ $args :  this array is default value of menu Transmission
		 */
		function end_el(&$output, $item, $depth = 0, $args = array()) {
			$output .= "\n$this->indent</li>\n";
		}
	}
}




